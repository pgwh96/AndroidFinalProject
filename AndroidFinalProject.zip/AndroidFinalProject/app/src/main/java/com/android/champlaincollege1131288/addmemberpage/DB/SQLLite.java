package com.android.champlaincollege1131288.addmemberpage.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import com.android.champlaincollege1131288.addmemberpage.Models.Profile;

public class SQLLite {

    private static final int DATABASE_VERSION = 1;

    //https://www.tutorialspoint.com/android/android_sqlite_database.htm

    // Database Name
    //private static final String DATABASE_NAME = "User_db";

    //SQLiteDatabase DB = SQLiteDatabase.openOrCreateDatabase("DB",MODE_PRIVATE,null);
    // ask about this, android studio doesn't recognize MODE_PRIVATE
    //use the following for now
    SQLiteDatabase DB = SQLiteDatabase.openOrCreateDatabase("DB",null,null);

    //public SQLLite(Context context) { super(context, "DB", null, DATABASE_VERSION); }

    public Profile addNewUser(Profile user)
    {
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(Profile.COLUMN_Uname, user.getUsername());
        values.put(Profile.COLUMN_Email, user.getEmail());
        values.put(Profile.COLUMN_Pword, user.getPassword());

        long id = db.insert(Profile.TABLE_NAME, null, values);
        db.close();

        user.setID((int)id);

        return user;
    }

    public Profile SignIn(Profile user)
    {
        String query = "SELECT  * FROM " + Profile.TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst())
        {
            Profile u = new Profile();
            if(u.getUsername() == cursor.getString(cursor.getColumnIndex(Profile.COLUMN_Uname))){}
            if(u.getPassword() == cursor.getString(cursor.getColumnIndex(Profile.COLUMN_Uname)))){}



            u.setUsername(cursor.getString(cursor.getColumnIndex(Profile.COLUMN_Uname)));
            u.setPassword(cursor.getString(cursor.getColumnIndex(Profile.COLUMN_Uname)));
        }

        db.close();

        return user;

    }

    @Override
    public void onCreate(SQLiteDatabase db) { db.execSQL(Profile.CREATE_TABLE);}

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

}
