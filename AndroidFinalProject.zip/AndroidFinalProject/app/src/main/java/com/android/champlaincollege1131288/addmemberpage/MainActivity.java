package com.android.champlaincollege1131288.addmemberpage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // the onClick method for the login button
    public void btn_signup(View view)
    {
        // creating these variables so I don't have to write "findViewById(R.id...)"
        // every time I want to reference something with an id in the activity.xml

        EditText txt_email = findViewById(R.id.inputEmail);
        EditText txt_username = findViewById(R.id.inputName);
        EditText txt_password = findViewById(R.id.inputPass);

        String email;
        String username;
        String password;

        //error message if things don't work
        String msg="";
        boolean err = false;

        // input validation
        if(txt_email == null ||txt_username == null || txt_password ==  null){
            msg = "you must enter your username and password to login";
            err = true;
        }
       /* else if((txt_username.toString().trim().length() < 6 && txt_username.toString().trim().length() > 15)||(txt_password.length() < 6 && txt_password.length() > 25)){
            msg = "usernames must be between 6 and 15 characters and passwords must be between 6 and 25 characters";
            err = true;
        }*/
        else{
            //this should eventually be replaced with prepared statements
            try{
                email = txt_email.toString().trim();
                username = txt_username.toString().trim();
                password = txt_password.toString().trim();

                //enter into db here


            }
            catch(Exception e){
                msg = "Error occurred";
                err = true;
            }

            if(err){
                Toast errmsg = Toast.makeText(getApplicationContext(),
                        msg,Toast.LENGTH_SHORT);
                errmsg.show();
            }
            else{
                //sends you to main menu
                Intent i = new Intent(getApplicationContext(),Main2Activity.class);
                startActivity(i);
            }
        }
        if(err){
            Toast errmsg = Toast.makeText(getApplicationContext(),
                    msg,Toast.LENGTH_SHORT);
            errmsg.show();
        }
    }
}
