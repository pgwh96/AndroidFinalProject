package com.android.champlaincollege1131288.addmemberpage.Models;

public class Profile {

    public static final String TABLE_NAME = "Profiles";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_Uname = "Username";
    public static final String COLUMN_Email = "Email";
    public static final String COLUMN_Pword = "Password";

    // DB create
    public static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_Uname + " TEXT,"
            + COLUMN_Email + " TEXT,"
            + COLUMN_Pword + " TEXT";

    private Integer ID;
    private String Username;
    private String Email;
    private String Password;

    public Profile(){}
    public Profile(String user,String em,String pass)
    {
        this.ID = null;
        this.Username = user;
        this.Email = em;
        this.Password = pass;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }
}
